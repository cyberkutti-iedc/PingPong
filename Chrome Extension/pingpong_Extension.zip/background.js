
function fetchNotifications() {
  chrome.storage.sync.get('githubUsername', function(data) {
      if (data.githubUsername) {
          fetch(`https://api.github.com/users/${data.githubUsername}/received_events`)
              .then(response => response.json())
              .then(events => {
                  // Get the most recent event
                  const latestEvent = events[0];
                  
                  // Check if this is a new event
                  chrome.storage.local.get('lastEventId', function(lastEventData) {
                      if (lastEventData.lastEventId !== latestEvent.id) {
                          // This is a new event, create a notification
                          chrome.notifications.create({
                              type: 'basic',
                              iconUrl: 'icons/icon128.png',
                              title: 'New GitHub Activity',
                              message: `${latestEvent.actor.login} ${latestEvent.type.replace('Event', '').toLowerCase()} ${latestEvent.repo.name}`
                          });

                          // Save this event ID
                          chrome.storage.local.set({lastEventId: latestEvent.id});
                      }
                  });
              })
              .catch(error => console.error('Error:', error));
      }
  });
}

// Fetch notifications every 5 minutes
setInterval(fetchNotifications, 5 * 60 * 1000);

// Also fetch immediately when the extension is loaded
fetchNotifications();