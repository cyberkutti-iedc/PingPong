document.addEventListener('DOMContentLoaded', function() {
    const usernameInput = document.getElementById('username');
    const saveButton = document.getElementById('save-button');
    const notificationList = document.getElementById('notification-list');

    // Load saved username
    chrome.storage.sync.get('githubUsername', function(data) {
        if (data.githubUsername) {
            usernameInput.value = data.githubUsername;
            fetchNotifications(data.githubUsername);
        }
    });

    // Save username
    saveButton.addEventListener('click', function() {
        const username = usernameInput.value.trim();
        if (username) {
            chrome.storage.sync.set({githubUsername: username}, function() {
                console.log('Username saved');
                fetchNotifications(username);
            });
        }
    });

    function fetchNotifications(username) {
        fetch(`https://api.github.com/users/${username}/received_events`)
            .then(response => response.json())
            .then(data => {
                notificationList.innerHTML = '';
                data.slice(0, 5).forEach(event => {
                    const li = document.createElement('li');
                    li.innerHTML = `
                        <a href="${event.repo.url}" target="_blank">
                            ${event.actor.login} ${event.type.replace('Event', '').toLowerCase()} ${event.repo.name}
                        </a>
                    `;
                    notificationList.appendChild(li);
                });
            })
            .catch(error => {
                console.error('Error fetching notifications:', error);
                notificationList.innerHTML = '<li>Error fetching notifications</li>';
            });
    }
});